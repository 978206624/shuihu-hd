# 水浒神兽 · Milestone 1

本地私用的浏览器重制实验。原 ROM、CPU、MBC5、游戏脚本、碰撞、随机数与游戏内存档格式未修改。请勿公开分发包含 ROM 的文件包。

## 启动

在 `/workspace/shawu/web` 运行：

```bash
python3 -m http.server 8765 --bind 0.0.0.0
```

然后打开 **http://localhost:8765**，点击「开始 / 继续」。需要支持 WebAssembly 的现代浏览器。不要直接双击 HTML 使用 `file://` 打开。启动时 ROM 有原作片头；可以按 Enter 进入标题菜单，X 确认开始。

这里的「离线」指服务器启动后，全部 JS、WASM、ROM、字体替代、图片均由本地提供，没有 CDN、第三方运行资源或遥测。无需 npm 构建。浏览器第一次访问也必须能连接本地 HTTP 服务器。没有 Service Worker，不声称关闭本地服务器仍能冷启动。绑定 0.0.0.0 会让同网段设备能够访问，请仅在自己的可信网络私用。

## 操作与存档

- 方向键移动；X = A，Z = B；Enter = START；左右 Shift = SELECT；空格暂停。
- 页面提供同等触控按键，支持多指按住；取消触摸或失去焦点会释放按键。失去焦点/切到后台会暂停。
- 「开始 / 继续」恢复模拟器运行；「暂停」停止推进；「声音」需点击启用。声音在默认状态关闭。
- 「原版像素 / 高清显示」只切换渲染器，不切换游戏状态。
- 游戏内存档后的电池 RAM 每秒写入当前来源的 localStorage，离页时也保存。导出为原始 `.sav`，没有自定义包装。此 ROM 的核心电池 RAM 为 2048 字节。
- 导入检查精确字节数，并交给核心读取；导入后刷新，在原作标题选择继续。错误大小不会写入。浏览器清理站点数据、隐私模式、不同端口或不同主机名会影响本地存档，请导出备份。
- 自动保存的是电池 RAM，不是随时存档：游戏内仍需使用原作自己的存档功能。此次测试验证了 RAM 字节持久化及导入导出，**尚未证明游戏内存档→重启→继续的完整流程**，不应把空白 RAM 的字节回读等同于该流程。

## 实际重绘范围

**标题**：来源为用户此前通过 GPT 网关生成并批准的 V4 图 `assets/title_hd.png`。识别条件是标题文字四个固定位置的完整 8×8 RGB 像素完全相等；不依赖按键计数，也不会在森林显示标题概念图。仅原始画面的上方 82 行（160×82）使用此图的对应上半部。下方 62 行（菜单、游标、版权）逐像素保留原作，再最近邻放大；测试验证这一区域的原版/高清输出完全相同。因此存在明确的高清/像素接合边界。

**森林**：监督方通过用户 GPT 网关、`gpt-image-2` 提供了 94 格图集，16 列×6 行，每格 32×32，图集 512×192。来源记录位于 `assets/forest/provenance.json`，源图为实际浏览器核心帧提取的背景格。未使用整屏森林插画替换玩法。

每帧读取原始 160×144 framebuffer 和 SCX/SCY；以真实滚动偏移定位完整 8×8 格。每格全部 64 个 RGB 像素（包括调色板结果）与 `mapping.json` 精确匹配后，才将对应的 32×32 GPT 纹理画到同一位置。屏幕边缘不完整格、未知格、不同调色板或含人物/窗口的混合格不匹配时都保留原输出。没有通过读写 VBK 改变核心寄存器；映射不是全游戏 VRAM/OAM 解码器。精确 RGB 匹配无哈希碰撞，但覆盖范围有限。

参考提取会排除 OAM 人物区域及窗口，并额外留一格保护边界；OAM 不可读取的采样帧被丢弃。渲染时使用**完整已合成画面格匹配**，因此人物覆盖背景会使该格退出替换，不需要伪造人物层。原始人物、神兽、头像、文字和菜单未重画；未匹配区域使用下述平滑。人物周围可能保留原始地面小方格，图集内也有接缝、重复纹理或 AI 解释差异。该素材包是早期局部纹理重绘，不是完整地图/人物重制。

**其他内容**：高清模式下使用独立 WebGL Scale2x 边缘感知算法，仅平滑原像素，不称作重绘。WebGL 不可用时退回最近邻。原版模式始终是核心原始画面最近邻放大。所有显示操作均不回写 ROM 或游戏内存。

图集可替换路径：`assets/forest/atlas_hd.png`。必须保持 512×192、32px 格、同一格顺序及对应关系；尺寸错误不会启用替换。不要用整幅风景图放到此路径冒充图集。缺失或无效时保留原游戏输出。

## 核心、来源及校验

使用原样 vendored Binjgb JS/WASM，MIT，源版本与下载地址见 `vendor/README.txt`，许可证随包提供。应用界面、适配器、渲染层及测试为本次自行编写，没有修改模拟器 CPU/PPU/计时实现。

ROM `assets/game.gbc` 是用户私有本地副本；2,097,152 字节；SHA256：

```text
ab42ec7ab339125dc685f4aa56eedfafaa2a8ecf46a4659e3c0f05eedd57ff95
```

启动时验证该 SHA256。支持 CGB，卡带 0x1B / MBC5 + RAM + Battery。实际测试可运行此 ROM 的片头、标题、开场与森林移动；不代表已验证全部战斗或通关。

## 调试与测试

`window.shuihu` 在资源准备完成后可用，应用默认暂停，适合确定性测试：

```js
shuihu.pause(true)
shuihu.step(120)            // 每次推进 70224 个基础时钟 tick，处理核心帧/音频事件
shuihu.input('right', true)
shuihu.step(30)
shuihu.input('right', false)
shuihu.setHD(false)
shuihu.meta()              // ticks、PC、滚动、识别场景、替换数量、ROM SHA256
const checkpoint = shuihu.checkpoint()
shuihu.step(60)
shuihu.restoreCheckpoint(checkpoint)
```

完整 `checkpoint()` 保存当前 WASM heap 和主机输入元数据，只用于**同一页面、同一核心版本**的可复现调试；包括核心普通状态没有包含的音频采样缓冲相位与 framebuffer。切换显示不改动此内存。`state()` / `loadState(array)` 是 Binjgb 原始核心状态字节，适合跨测试加载早期场景，但其格式不包含完整主机音频相位和 framebuffer，加载后需推进几帧恢复画面。**PyBoy 的 `.state` 不兼容**，此次浏览器森林来自真实按键推进而非移植 PyBoy 状态。`battery()` / `loadBattery(array)`、`persist()`、`pixels()`、只读 `read(address)`、`captureReference()` 可辅助测试。`meta().frames` 是页面推进计数，跨普通核心存档加载时仍累加；核心 `ticks` 才是模拟时间依据。

测试只使用独立无头 Chromium 的新建隔离上下文，不控制桌面或已登录浏览器。保持上述服务器运行，再执行：

```bash
cd /workspace/shawu/m1-work
npm --cache /tmp/shuihu-npm install playwright
PLAYWRIGHT_BROWSERS_PATH=/workspace/shawu/m1-work/browsers npx --cache /tmp/shuihu-npm playwright install chromium
cd /workspace/shawu/web
NODE_PATH=/workspace/shawu/m1-work/node_modules PLAYWRIGHT_BROWSERS_PATH=/workspace/shawu/m1-work/browsers node tools/test_m1.cjs
```

测试从冷启动真实推进到标题和森林；截图及 JSON 报告写入 `/workspace/shawu/shots/m1_*`。包括标题匹配/菜单输入、菜单带像素一致、森林滚动、同完整快照和同输入下原版/高清的核心状态逐字节一致、真实 CDP 触摸与键盘输入、电池 RAM 回读及导入导出、错误大小拒绝、暂停/继续、Web Audio 初始化、桌面/手机布局、运行错误与外部请求检查。音频测试不是人工听感验证。报告明确列出未测试的完整游戏内保存继续流程。未做全游戏兼容承诺。

`tools/build_forest_reference.py` 和 `tools/extract_pyboy_reference.py` 是提取研究助手，需已有 Pillow/PyBoy；不要在发布流程中自动重建正式美术映射。它们不是运行时依赖。完整测试结果见包内 `screenshots/m1_test_report.json`；截图展示的是实际运行画面。
